#include <SPI.h>
#include <Wire.h>
#include <LoRa.h>
#include <WiFi.h>
#include <HTTPClient.h>

#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// =====================================================
// WIFI
// =====================================================
const char* ssid = "SSID_WIFI";
const char* password = "PASS_WIFI";

// =====================================================
// MULTIPLE WEBHOOK URLS
// =====================================================
String webhookURLs[] = {
  "URL WEBHOOK 1",
  "URL WEBHOOK 2"
};

// Menghitung otomatis jumlah URL di dalam array
const int numWebhooks = sizeof(webhookURLs) / sizeof(webhookURLs[0]);

// =====================================================
// OLED
// =====================================================
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64

Adafruit_SSD1306 display(
  SCREEN_WIDTH,
  SCREEN_HEIGHT,
  &Wire,
  -1
);

// =====================================================
// PIN TTGO T3 V1.6.1
// =====================================================
#define SCK     5
#define MISO    19
#define MOSI    27
#define SS      18
#define RST     14
#define DIO0    26

// =====================================================
// FREKUENSI
// =====================================================
#define BAND 433E6

String incoming = "";

// =====================================================
// STORAGE NODE DATA
// =====================================================
bool node1Ready = false;
bool node2Ready = false;

String soilValue = "";

int nitrogenVal = 0;
int phosphorusVal = 0;
int potassiumVal = 0;

float temperatureVal = 0;
float humidityVal = 0;

// =====================================================
// WIFI RECONNECT TIMER
// =====================================================
unsigned long lastReconnectAttempt = 0;

// =====================================================
// SETUP
// =====================================================
void setup() {

  Serial.begin(115200);
  delay(1000);

  // =====================================================
  // OLED START
  // =====================================================
  Wire.begin(21, 22);

  if (!display.begin(
        SSD1306_SWITCHCAPVCC,
        0x3C)) {

    Serial.println("OLED gagal start!");

    while (1);
  }

  display.clearDisplay();

  display.setTextSize(1);
  display.setTextColor(WHITE);

  display.setCursor(0, 0);
  display.println("Starting...");
  display.display();

  // =====================================================
  // WIFI CONNECT
  // =====================================================
  connectWiFi();

  // =====================================================
  // SPI
  // =====================================================
  SPI.begin(SCK, MISO, MOSI, SS);

  // =====================================================
  // LORA
  // =====================================================
  LoRa.setPins(SS, RST, DIO0);

  if (!LoRa.begin(BAND)) {

    Serial.println("LoRa gagal!");

    display.clearDisplay();
    display.setCursor(0, 0);
    display.println("LoRa FAILED!");
    display.display();

    while (1);
  }

  LoRa.setSyncWord(0xF3);

  Serial.println("LoRa berhasil!");

  display.clearDisplay();
  display.setCursor(0, 0);
  display.println("LoRa READY");
  display.println("Waiting data...");
  display.display();
}

// =====================================================
// LOOP
// =====================================================
void loop() {

  // =====================================================
  // AUTO RECONNECT WIFI
  // =====================================================
  if (WiFi.status() != WL_CONNECTED) {

    if (millis() - lastReconnectAttempt > 10000) {

      Serial.println("=================================");
      Serial.println("WiFi Disconnect!");
      Serial.println("Mencoba reconnect...");
      Serial.println("=================================");

      connectWiFi();

      lastReconnectAttempt = millis();
    }
  }

  // =====================================================
  // CHECK LORA PACKET
  // =====================================================
  int packetSize = LoRa.parsePacket();

  if (packetSize) {

    incoming = "";

    while (LoRa.available()) {

      incoming += (char)LoRa.read();
    }

    Serial.println("=================================");
    Serial.println("RAW DATA:");
    Serial.println(incoming);
    Serial.println("=================================");

    processData(incoming);
  }

  delay(10);
}

// =====================================================
// CONNECT WIFI
// =====================================================
void connectWiFi() {

  WiFi.mode(WIFI_STA);

  // NONAKTIFKAN WIFI SLEEP
  WiFi.setSleep(false);

  WiFi.begin(ssid, password);

  display.clearDisplay();
  display.setCursor(0, 0);
  display.println("Connecting WiFi");
  display.display();

  Serial.print("Connecting WiFi");

  int timeout = 0;

  while (WiFi.status() != WL_CONNECTED && timeout < 20) {

    delay(500);
    Serial.print(".");
    timeout++;
  }

  Serial.println();

  if (WiFi.status() == WL_CONNECTED) {

    Serial.println("WiFi Connected!");
    Serial.print("IP : ");
    Serial.println(WiFi.localIP());

    display.clearDisplay();
    display.setCursor(0, 0);
    display.println("WiFi Connected");
    display.println(WiFi.localIP());
    display.display();

    delay(2000);

  } else {

    Serial.println("Gagal connect WiFi!");

    display.clearDisplay();
    display.setCursor(0, 0);
    display.println("WiFi Failed!");
    display.display();
  }
}

// =====================================================
// PROCESS DATA
// =====================================================
void processData(String data) {

  // =====================================================
  // NODE1
  // FORMAT:
  // NODE1|soil=65
  // =====================================================
  if (data.startsWith("NODE1")) {

    int soilIndex = data.indexOf("soil=");

    if (soilIndex != -1) {

      String soil =
        data.substring(soilIndex + 5);

      int rssi = LoRa.packetRssi();
      float snr = LoRa.packetSnr();

      // =====================================================
      // SERIAL
      // =====================================================
      Serial.println("NODE1 diterima");

      // =====================================================
      // OLED
      // =====================================================
      display.clearDisplay();

      display.setTextSize(1);

      display.setCursor(0, 0);
      display.println("NODE1");

      display.setCursor(0, 15);
      display.print("Soil : ");
      display.println(soil);

      display.setCursor(0, 30);
      display.print("RSSI : ");
      display.println(rssi);

      display.setCursor(0, 45);
      display.print("SNR : ");
      display.println(snr);

      display.display();

      // =====================================================
      // SAVE DATA
      // =====================================================
      soilValue = soil;

      node1Ready = true;

      // =====================================================
      // CHECK SEND
      // =====================================================
      checkAndSendCombined();
    }
  }

  // =====================================================
  // NODE2
  // FORMAT:
  // NODE2|n=120,p=40,k=80,temp=29.4,hum=78
  // =====================================================
  else if (data.startsWith("NODE2")) {

    String payload =
      data.substring(data.indexOf("|") + 1);

    int nVal    = getIntValue(payload, "n=");
    int pVal    = getIntValue(payload, "p=");
    int kVal    = getIntValue(payload, "k=");

    float tVal  = getFloatValue(payload, "temp=");
    float hVal  = getFloatValue(payload, "hum=");

    int rssi = LoRa.packetRssi();
    float snr = LoRa.packetSnr();

    // =====================================================
    // SERIAL
    // =====================================================
    Serial.println("NODE2 diterima");

    // =====================================================
    // OLED
    // =====================================================
    display.clearDisplay();

    display.setTextSize(1);

    display.setCursor(0, 0);
    display.println("NODE2");

    display.setCursor(0, 10);
    display.print("N:");
    display.print(nVal);

    display.print(" P:");
    display.println(pVal);

    display.setCursor(0, 20);
    display.print("K:");
    display.print(kVal);

    display.setCursor(0, 30);
    display.print("T:");
    display.print(tVal);

    display.print(" H:");
    display.println(hVal);

    display.setCursor(0, 45);
    display.print("RSSI:");
    display.println(rssi);

    display.display();

    // =====================================================
    // SAVE DATA
    // =====================================================
    nitrogenVal = nVal;
    phosphorusVal = pVal;
    potassiumVal = kVal;

    temperatureVal = tVal;
    humidityVal = hVal;

    node2Ready = true;

    // =====================================================
    // CHECK SEND
    // =====================================================
    checkAndSendCombined();
  }

  // =====================================================
  // UNKNOWN FORMAT
  // =====================================================
  else {

    Serial.println("Format data tidak dikenali!");
  }
}

// =====================================================
// CHECK & SEND COMBINED DATA
// =====================================================
void checkAndSendCombined() {

  // =====================================================
  // KIRIM JIKA SEMUA NODE SUDAH ADA
  // =====================================================
  if (node1Ready && node2Ready) {

    String finalJson = "{";

    finalJson += "\"gateway\":\"LORA_GATEWAY\",";

    // =====================================================
    // NODE1
    // =====================================================
    finalJson += "\"soil_sensor\":{";

    finalJson += "\"soil_moisture\":";
    finalJson += soilValue;

    finalJson += "},";

    // =====================================================
    // NODE2
    // =====================================================
    finalJson += "\"environment_sensor\":{";

    finalJson += "\"nitrogen\":";
    finalJson += String(nitrogenVal);
    finalJson += ",";

    finalJson += "\"phosphorus\":";
    finalJson += String(phosphorusVal);
    finalJson += ",";

    finalJson += "\"potassium\":";
    finalJson += String(potassiumVal);
    finalJson += ",";

    finalJson += "\"temperature\":";
    finalJson += String(temperatureVal, 2);
    finalJson += ",";

    finalJson += "\"humidity\":";
    finalJson += String(humidityVal, 2);

    finalJson += "}";

    finalJson += "}";

    // =====================================================
    // SERIAL
    // =====================================================
    Serial.println("=================================");
    Serial.println("FINAL JSON");
    Serial.println(finalJson);
    Serial.println("=================================");

    // =====================================================
    // SEND TO MULTIPLE WEBHOOKS
    // =====================================================
    sendToWebhook(finalJson);

    // =====================================================
    // RESET FLAG
    // =====================================================
    node1Ready = false;
    node2Ready = false;
  }
}

// =====================================================
// SEND TO MULTIPLE WEBHOOKS
// =====================================================
void sendToWebhook(String jsonData) {

  // =====================================================
  // CEK WIFI
  // =====================================================
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("WiFi belum connect!");
    return;
  }

  Serial.println("Mulai mengirim data ke webhooks...");
  Serial.println(jsonData);
  Serial.println("---------------------------------");

  HTTPClient http;

  // Looping sebanyak jumlah URL yang ada di array
  for (int i = 0; i < numWebhooks; i++) {
    
    Serial.print("Mengirim ke Webhook ");
    Serial.print(i + 1);
    Serial.print(" : ");
    Serial.println(webhookURLs[i]);

    http.begin(webhookURLs[i]);

    // TIMEOUT AGAR TIDAK HANG
    http.setTimeout(5000);

    http.addHeader(
      "Content-Type",
      "application/json"
    );

    int httpResponseCode = http.POST(jsonData);

    Serial.print("HTTP Response : ");
    Serial.println(httpResponseCode);

    // =====================================================
    // RESPONSE
    // =====================================================
    if (httpResponseCode > 0) {
      String response = http.getString();
      Serial.println("Response:");
      Serial.println(response);
      Serial.println("Data berhasil dikirim ke URL ini!");
    } else {
      Serial.println("Gagal kirim data ke URL ini!");
      Serial.print("Error: ");
      Serial.println(http.errorToString(httpResponseCode));
    }
    
    Serial.println("---------------------------------");
    
    // PENTING: Akhiri koneksi untuk URL saat ini 
    // sebelum pindah ke iterasi URL berikutnya
    http.end(); 
  }
  
  Serial.println("Selesai mengirim ke semua webhooks.");
}

// =====================================================
// GET INTEGER
// =====================================================
int getIntValue(String data, String key) {

  int start = data.indexOf(key);

  if (start == -1) return 0;

  start += key.length();

  int end = data.indexOf(",", start);

  if (end == -1)
    end = data.length();

  return data.substring(start, end).toInt();
}

// =====================================================
// GET FLOAT
// =====================================================
float getFloatValue(String data, String key) {

  int start = data.indexOf(key);

  if (start == -1) return 0;

  start += key.length();

  int end = data.indexOf(",", start);

  if (end == -1)
    end = data.length();

  return data.substring(start, end).toFloat();
}